#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if [[ -z "${ANDROID_HOME:-}" && -d "$HOME/Android/Sdk" ]]; then
  export ANDROID_HOME="$HOME/Android/Sdk"
fi
if [[ -z "${ANDROID_SDK_ROOT:-}" && -n "${ANDROID_HOME:-}" ]]; then
  export ANDROID_SDK_ROOT="$ANDROID_HOME"
fi

GRADLE_BIN=""
for candidate in "${GRADLE_HOME:-}/bin/gradle" "$HOME/gradle-8.9/bin/gradle" \
  "/opt/gradle-8.9/bin/gradle" "$(command -v gradle || true)"; do
  if [[ -f "$candidate" && -x "$candidate" ]]; then
    GRADLE_BIN="$candidate"
    break
  fi
done
if [[ -z "$GRADLE_BIN" ]]; then
  echo "Gradle bulunamadı. Gradle 8.9 kur veya GRADLE_HOME tanımla." >&2
  exit 1
fi
if [[ -z "${ANDROID_HOME:-}" ]]; then
  echo "Android SDK bulunamadı. ANDROID_HOME değişkenini tanımla." >&2
  exit 1
fi

echo "Gradle: $GRADLE_BIN"
echo "Android SDK: $ANDROID_HOME"
"$GRADLE_BIN" --no-daemon :app:assembleDebug
printf '\nAPK: %s\n' "$PWD/app/build/outputs/apk/debug/app-debug.apk"
