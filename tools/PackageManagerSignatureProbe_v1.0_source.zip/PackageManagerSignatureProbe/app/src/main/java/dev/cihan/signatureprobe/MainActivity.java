package dev.cihan.signatureprobe;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** Simple standalone UI, no AndroidX dependencies or privileged permissions. */
public final class MainActivity extends Activity {
    private static final int CREATE_REPORT = 111;
    private TextView resultView;
    private String report = "Henüz tarama yapılmadı.";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(15, 23, 42));
        getWindow().setNavigationBarColor(Color.rgb(15, 23, 42));
        makeLayout();
        doScan();
    }

    private void makeLayout() {
        int navy = Color.rgb(15, 23, 42);
        int blue = Color.rgb(37, 99, 235);
        int gray = Color.rgb(71, 85, 105);
        float dp = getResources().getDisplayMetrics().density;
        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(Color.rgb(248, 250, 252));
        screen.setPadding((int)(16 * dp), (int)(12 * dp), (int)(16 * dp), (int)(12 * dp));
        setContentView(screen);

        TextView heading = new TextView(this);
        heading.setText("Signature Probe");
        heading.setTextColor(navy);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.setTextSize(24);
        screen.addView(heading);

        TextView subtitle = new TextView(this);
        subtitle.setText("Huawei P Smart S • microG-HW • Salt okunur teşhis");
        subtitle.setTextColor(gray);
        subtitle.setTextSize(13);
        subtitle.setPadding(0, (int)(4 * dp), 0, (int)(12 * dp));
        screen.addView(subtitle);

        LinearLayout firstRow = new LinearLayout(this);
        firstRow.setOrientation(LinearLayout.HORIZONTAL);
        firstRow.setGravity(Gravity.CENTER_VERTICAL);
        screen.addView(firstRow);
        Button scan = makeButton("Yeniden tara", blue);
        Button copy = makeButton("Kopyala", navy);
        firstRow.addView(scan, new LinearLayout.LayoutParams(0, (int)(48 * dp), 1));
        firstRow.addView(copy, new LinearLayout.LayoutParams(0, (int)(48 * dp), 1));

        LinearLayout secondRow = new LinearLayout(this);
        secondRow.setOrientation(LinearLayout.HORIZONTAL);
        screen.addView(secondRow);
        Button save = makeButton("TXT kaydet", navy);
        Button share = makeButton("Paylaş", navy);
        secondRow.addView(save, new LinearLayout.LayoutParams(0, (int)(48 * dp), 1));
        secondRow.addView(share, new LinearLayout.LayoutParams(0, (int)(48 * dp), 1));

        ScrollView scroll = new ScrollView(this);
        LinearLayout.LayoutParams scrollParams =
            new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1);
        scrollParams.topMargin = (int)(10 * dp);
        screen.addView(scroll, scrollParams);

        resultView = new TextView(this);
        resultView.setTextColor(navy);
        resultView.setTextSize(12);
        resultView.setTypeface(Typeface.MONOSPACE);
        resultView.setTextIsSelectable(true);
        resultView.setPadding((int)(12 * dp), (int)(12 * dp),
            (int)(12 * dp), (int)(12 * dp));
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.WHITE);
        background.setCornerRadius(12 * dp);
        background.setStroke((int)(1 * dp), Color.rgb(203, 213, 225));
        resultView.setBackground(background);
        scroll.addView(resultView);

        scan.setOnClickListener(v -> doScan());
        copy.setOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager)
                getSystemService(Context.CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("signature-probe", report));
            Toast.makeText(this, "Rapor panoya kopyalandı", Toast.LENGTH_SHORT).show();
        });
        save.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.setType("text/plain");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.putExtra(Intent.EXTRA_TITLE, "signature-probe-report.txt");
            startActivityForResult(intent, CREATE_REPORT);
        });
        share.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_TEXT, report);
            startActivity(Intent.createChooser(intent, "Raporu paylaş"));
        });
    }

    private Button makeButton(String label, int color) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
        return b;
    }

    private void doScan() {
        try {
            report = SignatureScanner.scan(this);
        } catch (Exception e) {
            report = "Tarama sırasında hata: " + e.toString();
        }
        resultView.setText(report);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != CREATE_REPORT || resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData();
        if (uri == null) return;
        try (OutputStream stream = getContentResolver().openOutputStream(uri)) {
            if (stream == null) throw new IllegalStateException("Yazma akışı yok");
            stream.write(report.getBytes(StandardCharsets.UTF_8));
            Toast.makeText(this, "Rapor kaydedildi", Toast.LENGTH_SHORT).show();
        } catch (Exception ex) {
            Toast.makeText(this, "Kaydetme başarısız: " + ex.getMessage(),
                Toast.LENGTH_LONG).show();
        }
    }
}
