package dev.cihan.signatureprobe;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.content.pm.ServiceInfo;
import android.content.pm.Signature;
import android.content.pm.SigningInfo;
import android.os.Build;

import java.io.ByteArrayInputStream;
import java.security.MessageDigest;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Read-only investigation of caller-visible Android package signatures.
 * Important: other apps can observe different results if a hook is caller-specific.
 */
public final class SignatureScanner {
    private static final String GMS = "com.google.android.gms";
    private static final String[] PACKAGES = {
        GMS,
        "com.android.vending",
        "com.google.android.gsf",
        "com.google.android.gm",
        "app.revanced.android.gms",
        "android"
    };
    // Reference supplied from an earlier Google-signed APK; not a universal GMS identity.
    private static final String USER_GOOGLE_REFERENCE_SHA256 =
        "F0FD6C5B410F25CB25C3B53346C8972FAE30F8EE7411DF910480AD6B2D60DB83";

    private SignatureScanner() { }

    public static String scan(Context context) {
        PackageManager pm = context.getPackageManager();
        StringBuilder out = new StringBuilder(7000);
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss Z", Locale.US);
        out.append("PACKAGE MANAGER SIGNATURE PROBE v1.0\n");
        out.append("Tarama: ").append(fmt.format(new Date())).append('\n');
        out.append("Cihaz: ").append(Build.MANUFACTURER).append(' ')
            .append(Build.MODEL).append(" / Android ").append(Build.VERSION.RELEASE)
            .append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        out.append("Sorgulayan paket: ").append(context.getPackageName()).append("\n\n");
        out.append("ÖNEMLİ: Bu rapor sadece BU uygulamanın PackageManager API'sinde ")
            .append("gördüğü verileri gösterir. Gmail'in kendi işleminde aynı sonuçları ")
            .append("aldığını kanıtlamaz. Root / imza değiştirme yoktur.\n\n");

        for (String packageName : PACKAGES) {
            scanPackage(pm, packageName, out);
        }

        out.append("=== API checkSignatures karşılaştırmaları ===\n");
        compare(pm, GMS, "com.android.vending", out);
        compare(pm, GMS, "com.google.android.gm", out);
        compare(pm, "com.android.vending", "com.google.android.gm", out);
        out.append("NOT: MATCH yalnızca iki paketin Android'e görünen imzalarının eşleştiğini belirtir; ")
            .append("Google sertifikası veya GMS uyumluluğu için kesin kanıt değildir.\n\n");

        scanHuaweiBridge(pm, out);
        out.append("=== Yorumlama ===\n");
        out.append("• GET_SIGNATURES eski, GET_SIGNING_CERTIFICATES Android 9+ yöntemidir.\n");
        out.append("• İki API'nin aynı sonucu vermesi sistem çapında spoofing var/yok kanıtı değildir.\n");
        out.append("• SignatureService'in kurulu/aktif/exported olması PackageManager'in onu kullandığını kanıtlamaz.\n");
        out.append("• Google referans SHA-256 değeri önceki Play Store incelemesindendir; ")
            .append("her Google APK'sında aynı imzayı beklemeyin.\n");
        out.append("• Rapor hesap, e-posta adresi, Android ID veya token toplamıyor.\n");
        return out.toString();
    }

    private static void scanPackage(PackageManager pm, String name, StringBuilder out) {
        out.append("=== ").append(name).append(" ===\n");
        try {
            int flags = PackageManager.GET_SIGNATURES | PackageManager.GET_SIGNING_CERTIFICATES;
            PackageInfo pi = pm.getPackageInfo(name, flags);
            out.append("Kurulu: evet\n");
            out.append("Sürüm: ").append(pi.versionName).append("\n");
            out.append("versionCode: ").append(pi.getLongVersionCode()).append("\n");
            out.append("Sistem uygulaması: ")
                .append((pi.applicationInfo != null
                    && (pi.applicationInfo.flags & android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0)
                    ? "evet" : "hayır").append("\n");

            writeSignatures("GET_SIGNATURES (eski API)", pi.signatures, out);
            SigningInfo info = pi.signingInfo;
            if (info == null) {
                out.append("GET_SIGNING_CERTIFICATES: SigningInfo null\n");
            } else {
                out.append("GET_SIGNING_CERTIFICATES / çoklu imzalayan: ")
                    .append(info.hasMultipleSigners()).append('\n');
                writeSignatures("Geçerli APK imzacıları", info.getApkContentsSigners(), out);
                if (!info.hasMultipleSigners()) {
                    writeSignatures("İmza geçmişi (varsa)", info.getSigningCertificateHistory(), out);
                }
            }
        } catch (PackageManager.NameNotFoundException e) {
            out.append("Kurulu değil veya bu uygulamadan görünmüyor\n");
        } catch (RuntimeException e) {
            out.append("Paket sorgusu başarısız: ").append(e.getClass().getSimpleName()).append('\n');
        }
        out.append('\n');
    }

    private static void writeSignatures(String label, Signature[] signatures, StringBuilder out) {
        out.append(label).append(": ");
        if (signatures == null || signatures.length == 0) {
            out.append("yok\n");
            return;
        }
        out.append(signatures.length).append(" adet\n");
        for (int i = 0; i < signatures.length; i++) {
            try {
                byte[] raw = signatures[i].toByteArray();
                String sha256 = digest(raw, "SHA-256");
                out.append("  [").append(i + 1).append("] SHA-256: ").append(sha256).append('\n');
                out.append("      SHA-1: ").append(digest(raw, "SHA-1")).append('\n');
                out.append("      Önceki Google APK referansıyla eşleşiyor: ")
                    .append(USER_GOOGLE_REFERENCE_SHA256.equals(sha256) ? "EVET" : "hayır")
                    .append('\n');
                try {
                    X509Certificate cert = (X509Certificate) CertificateFactory
                        .getInstance("X.509")
                        .generateCertificate(new ByteArrayInputStream(raw));
                    out.append("      Sertifika konu: ")
                        .append(cert.getSubjectX500Principal().getName()).append('\n');
                    out.append("      Sertifika veren: ")
                        .append(cert.getIssuerX500Principal().getName()).append('\n');
                } catch (Exception certificateError) {
                    out.append("      X.509 çözümlemesi yapılamadı\n");
                }
            } catch (Exception digestError) {
                out.append("  [").append(i + 1).append("] sertifika okunamadı: ")
                    .append(digestError.getClass().getSimpleName()).append('\n');
            }
        }
    }

    private static String digest(byte[] bytes, String algorithm) throws Exception {
        byte[] hashed = MessageDigest.getInstance(algorithm).digest(bytes);
        StringBuilder result = new StringBuilder(hashed.length * 2);
        for (byte b : hashed) {
            result.append(Character.forDigit((b >>> 4) & 0xF, 16));
            result.append(Character.forDigit(b & 0xF, 16));
        }
        return result.toString().toUpperCase(Locale.US);
    }

    private static void compare(PackageManager pm, String a, String b, StringBuilder out) {
        int match = pm.checkSignatures(a, b);
        String label;
        if (match == PackageManager.SIGNATURE_MATCH) {
            label = "MATCH";
        } else if (match == PackageManager.SIGNATURE_NO_MATCH) {
            label = "NO_MATCH";
        } else if (match == PackageManager.SIGNATURE_UNKNOWN_PACKAGE) {
            label = "UNKNOWN_PACKAGE";
        } else {
            label = "kod " + match;
        }
        out.append(a).append(" ↔ ").append(b).append(": ").append(label).append('\n');
    }

    private static void scanHuaweiBridge(PackageManager pm, StringBuilder out) {
        out.append("=== Huawei Signature Bridge bileşenleri ===\n");
        ComponentName service = new ComponentName(GMS,
            "com.huawei.signature.diff.SignatureService");
        ComponentName provider = new ComponentName(GMS,
            "com.huawei.signature.diff.InitProvider");
        ComponentName receiver = new ComponentName(GMS,
            "com.huawei.signature.diff.InitReceiver");

        try {
            ServiceInfo info = pm.getServiceInfo(service, 0);
            out.append("SignatureService tanımlı: evet\n");
            out.append("  enabled: ").append(info.enabled).append('\n');
            out.append("  exported: ").append(info.exported).append('\n');
            out.append("  permission: ").append(info.permission == null ? "yok" : info.permission).append('\n');
            Intent query = new Intent("com.huawei.signature.diff").setPackage(GMS);
            ServiceInfo resolved = null;
            android.content.pm.ResolveInfo resolver = pm.resolveService(query, 0);
            if (resolver != null) resolved = resolver.serviceInfo;
            out.append("Intent resolveService: ")
                .append(resolved == null ? "sonuç yok" : resolved.name).append('\n');
        } catch (PackageManager.NameNotFoundException e) {
            out.append("SignatureService tanımlı: hayır / görünmüyor\n");
        } catch (RuntimeException e) {
            out.append("SignatureService sorgusu başarısız: ")
                .append(e.getClass().getSimpleName()).append('\n');
        }

        try {
            ProviderInfo info = pm.getProviderInfo(provider, 0);
            out.append("InitProvider tanımlı: evet, enabled=").append(info.enabled)
                .append(", exported=").append(info.exported).append('\n');
        } catch (PackageManager.NameNotFoundException e) {
            out.append("InitProvider tanımlı: hayır / görünmüyor\n");
        } catch (RuntimeException e) {
            out.append("InitProvider sorgusu başarısız: ")
                .append(e.getClass().getSimpleName()).append('\n');
        }

        try {
            android.content.pm.ActivityInfo info = pm.getReceiverInfo(receiver, 0);
            out.append("InitReceiver tanımlı: evet, enabled=").append(info.enabled)
                .append(", exported=").append(info.exported).append('\n');
        } catch (PackageManager.NameNotFoundException e) {
            out.append("InitReceiver tanımlı: hayır / görünmüyor\n");
        } catch (RuntimeException e) {
            out.append("InitReceiver sorgusu başarısız: ")
                .append(e.getClass().getSimpleName()).append('\n');
        }
        out.append("NOT: Bu sorgular servisi başlatmaz, bağlanmaz veya firmware'i yamalamaz.\n\n");
    }
}
