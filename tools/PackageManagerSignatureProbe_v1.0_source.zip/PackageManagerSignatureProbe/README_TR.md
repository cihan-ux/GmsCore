# PackageManager Signature Probe v1.0

**Hedef cihaz:** Huawei P Smart S (AQM-LX1 / AQM-L21A), EMUI 12, Android 10 (API 29).

Bu proje sistem imzasını **değiştirmez**. Tamamen salt okunur Android uygulamasıdır. Root, Shizuku, GMS, internet veya herhangi bir Android izni istemez. Telefonda microG-HW, Gmail ve Play Store'un Android PackageManager tarafından **bu uygulamaya** sunulan imza bilgilerini inceler.

## Özellikler

- `GET_SIGNATURES` (eski API) ve `GET_SIGNING_CERTIFICATES` (Android 9+) sonuçları.
- Her geçerli sertifikanın SHA-256/SHA-1 özetleri ve X.509 konu/veren bilgileri.
- İmza geçmişi (rotation) varsa listeler.
- `PackageManager.checkSignatures()` ile microG-HW / Play Store / Gmail karşılaştırması.
- `com.huawei.signature.diff.SignatureService`, `InitProvider`, `InitReceiver` tanımlarını denetler.
- İçerik TXT olarak kaydedilebilir, kopyalanabilir veya paylaşılabilir.
- İsteğe bağlı referans: daha önce App Manager'da görülen Google sertifika SHA-256'sı `F0FD6C5B...60DB83`. **Bu bütün Google APK'ları için zorunlu bir imza değildir.**

## Gerekenler

- Linux Mint, JDK 17 veya 21, Android SDK Platform 35 ve Build Tools 35.0.0.
- Gradle 8.9 (kullanıcının daha önce kurduğu sürüm), Android Gradle Plugin 8.7.3.
- İnternet ilk derleme sırasında Gradle/AGP bağımlılıkları için gerekebilir.

SDK bileşenleri eksikse (sdkmanager kuruluysa):

```bash
sdkmanager "platforms;android-35" "build-tools;35.0.0"
```

## Derleme

```bash
unzip PackageManagerSignatureProbe_v1.0_source.zip
cd PackageManagerSignatureProbe
chmod +x build-apk.sh
./build-apk.sh
```

Eğer Gradle yalnızca başka bir klasördeyse, örneğin:

```bash
export GRADLE_HOME="$HOME/gradle-8.9"
export ANDROID_HOME="$HOME/Android/Sdk"
./build-apk.sh
```

Oluşan dosya: `app/build/outputs/apk/debug/app-debug.apk`.

## Kurulum

Linux Mint'ten ADB ile:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Telefondan da bu APK dosyasını normal bir uygulama olarak kurabilirsin. Başka bir uygulamanın yerine kurulmaz; paket adı `dev.cihan.signatureprobe`.

## Kullanım

1. **Signature Probe** uygulamasını aç; ilk tarama otomatik başlar.
2. **TXT kaydet** ile raporu Dosyalar/İndirilenler'e kaydet.
3. `signature-probe-report.txt` dosyasını buraya yükle.
4. Pakette `com.google.android.gms` için `GET_SIGNATURES` ve `GET_SIGNING_CERTIFICATES` değerlerini karşılaştıracağız.

## Önemli sınırlamalar

1. Tek bir test uygulamasının gördüğü `PackageManager` bilgisi, Gmail'in **kendi işleminde** aynı sorgunun aynı sonucu aldığı anlamına gelmez. Özellikle uygulama-özel imza yamaları bu sonucu değiştirebilir.
2. Huawei SignatureService'in kurulu ve `exported` olması bile sistemin ondan imza aldığını **kanıtlamaz**.
3. `checkSignatures()` eşleşmesi Google'ın gerçek GMS sertifikasının kabul edildiğini kanıtlamaz. **Bu bir tanılama aracı, spoofing testi için nihai otorite değil.**
4. Uygulama framework kodunu, bootloader'ı veya SELinux politikasını değiştiremez.
5. Uygulama başka APK'ları yamalamaz, imzalamaz veya kaldıramaz.

## Güvenlik

Android ID, hesap adresi, token, paket içerikleri veya rehber okunmaz. İnternet izni yoktur. Raporu paylaştığında cihaz modeli ve yüklü hedef paket sürümleri görünür. Kaydetme için Android dosya seçicisi kullanılır.

## Kaynaklar

- https://developer.android.com/reference/android/content/pm/PackageManager
- https://developer.android.com/reference/android/content/pm/SigningInfo

Lisans: MIT.

## GitHub Actions ile APK derlemek (bilgisayarda SDK gerekmez)

1. GitHub'da yeni bir depo aç; ZIP'in içindeki proje **dosyalarını depo köküne** yükle.
2. Depoda **Actions → Android APK (debug) → Run workflow** seç.
3. Tamamlandığında `signature-probe-debug-apk` adlı artifact'i indir.
4. Artifact ZIP'inin içinde `app-debug.apk` bulunur. Telefonda açıp kurabilirsin.

İş akışı `.github/workflows/build-apk.yml` içinde. Bu repo/depo otomatik oluşturulmaz ve kullanıcı izni olmadan yayımlanmaz.
